// src/hooks/useAuth.ts
"use client";

import { useRouter } from "next/navigation";