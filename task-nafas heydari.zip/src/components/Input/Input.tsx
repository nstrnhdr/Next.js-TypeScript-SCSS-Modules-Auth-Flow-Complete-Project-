// src/components/Input/Input.tsx
"use client";

import React, { forwardRef, InputHTMLAttributes } from "react";
import styles from "./Input.module.scss";

interface Props extends InputHTMLAttributes<HTMLInputElement> {
  error?: string | boolean;
}

const Input = forwardRef<HTMLInputElement, Props>(({ className = "", error, ...props }, ref) => {
  return (
    <div className={styles.wrapper}>
      <input ref={ref} className={`${styles.input} ${className}`} {...props} />
    </div>
  );
});

Input.displayName = "Input";
export default Input;