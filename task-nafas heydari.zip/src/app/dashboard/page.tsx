// src/app/dashboard/page.tsx
"use client";

import React, { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import styles from "./dashboard.module.scss";
import { UserData } from "@/utils/types";

export default function DashboardPage() {
  const [user, setUser] = useState<UserData | null>(null);
  const router = useRouter();

  useEffect(() => {
    if (typeof window !== "undefined") {
      const raw = localStorage.getItem("user");
      if (!raw) {
        router.replace("/auth");
        return;
      }
      try {
        const parsed = JSON.parse(raw) as UserData;
        setUser(parsed);
      } catch (e) {
        localStorage.removeItem("user");
        router.replace("/auth");
      }
    }
  }, [router]);

  const handleLogout = () => {
    if (typeof window !== "undefined") {
      localStorage.removeItem("user");
      router.push("/auth");
    }
  };

  return (
    <main className={styles.wrapper}>
      <div className={styles.container}>
        <h1>Welcome to the Dashboard</h1>
        {user ? (
          <div className={styles.profile}>
            <img src={user.picture?.medium} alt="avatar" className={styles.avatar} />
            <div>
              <p className={styles.name}>{user.name.first} {user.name.last}</p>
              <p className={styles.email}>{user.email}</p>
            </div>
          </div>
        ) : (
          <p>Loading profile...</p>
        )}

        <button className={styles.logout} onClick={handleLogout}>Logout</button>
      </div>
    </main>
  );
}