// src/app/layout.tsx
import "./globals.scss";
import type { PropsWithChildren } from "react";

export const metadata = {
  title: "Auth Dashboard",
  description: "Minimal auth flow with Next.js App Router",
};

export default function RootLayout({ children }: PropsWithChildren) {
  return (
    <html lang="en">
      <body>
        {children}
      </body>
    </html>
  );