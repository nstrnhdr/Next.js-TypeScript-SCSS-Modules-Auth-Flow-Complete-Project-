// src/app/auth/page.tsx
"use client";

import React, { useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import Input from "@/components/Input/Input";
import Button from "@/components/Button/Button";
import styles from "./auth.module.scss";
import { useRouter } from "next/navigation";

// Schema: Iranian mobile numbers for validation practice
const schema = z.object({
  phone: z.string().regex(/^09\d{9}$/, "Phone must start with 09 and be 11 digits"),
});

type FormData = z.infer<typeof schema>;

export default function AuthPage() {
  const router = useRouter();

  const { register, handleSubmit, formState, setError } = useForm<FormData>({
    resolver: zodResolver(schema),
    mode: "onSubmit",
  });

  const onSubmit = async (data: FormData) => {
    try {
      const res = await fetch("https://randomuser.me/api/?results=1&nat=us");
      if (!res.ok) throw new Error("API error");
      const json = await res.json();
      const user = json.results[0];

      // store user data in localStorage
      if (typeof window !== "undefined") {
        localStorage.setItem("user", JSON.stringify(user));
      }

      router.push("/dashboard");
    } catch (err) {
      // Generic error handling - show as form error
      setError("phone", { type: "manual", message: "Login failed. Try again." });
      console.error(err);
    }
  };

  // If already logged in, redirect to dashboard
  useEffect(() => {
    if (typeof window !== "undefined") {
      const stored = localStorage.getItem("user");
      if (stored) router.replace("/dashboard");
    }
  }, [router]);

  return (
    <main className={styles.wrapper}>
      <div className={styles.card}>
        <h1 className={styles.title}>Login</h1>
        <p className={styles.subtitle}>Please enter your phone number to sign in (validation practice only)</p>

        <form onSubmit={handleSubmit(onSubmit)} className={styles.form} noValidate>
          <Input
            {...register("phone")}
            id="phone"
            type="tel"
            placeholder="09xxxxxxxxx"
            aria-label="Iranian mobile number"
          />
          {formState.errors.phone && <div className={styles.error}>{formState.errors.phone.message}</div>}

          <Button type="submit" aria-label="Login">Login</Button>
        </form>
      </div>
    </main>
  );